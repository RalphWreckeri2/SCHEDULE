<?php
header("Location: dashboard.php");
exit();
